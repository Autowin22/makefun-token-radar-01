# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## PROMPT INDUK — aturan tetap user (2026-11-13)
- Dokumen aturan tetap dari user tersimpan UTUH (bukan ringkasan) di `~/workspace/prompt-induk.md` — 15 bagian (0–14). Baca dan patuhi untuk semua tugas sampai user mencabutnya. Yang paling mengikat: bagian 2 (hukum bukti — klaim hanya dari respons langsung sistem/API/on-chain/isi file; nilai teknis tidak pernah dari bacaan model/screenshot/chat) dan bagian 9 (8 anti-pattern). Bagian 12.1 sejalan dengan aturan lama "konfirmasi dulu wajib": tanda tangan transaksi / belanja dana / publish atas nama user / hapus data tak terpulihkan = tanya dulu.

## Git push "invalid credentials" on a fresh VM (2026-11-19)
- A new VM generation shipped `~/.gitconfig` (mtime 2026-11-19 08:07 UTC) with a stale global `[http] extraHeader = Authorization: Bearer <token>`. Git then sends Bearer auth to github.com (rejected: "invalid credentials") instead of Basic from the `gh auth git-credential` helper — even though `gh api` works and the token has push permission (curl with Basic → HTTP 200 proves the token is fine). Fix: `git config --global --unset http.extraHeader`, then push works. If a push fails with "invalid credentials" while `gh api user` works, check `git config --list | grep http.` for a stale extraHeader first.

## baw preview "clean" check (2026-11-11)
- `baw contract-call preview` returns `risks` as an OBJECT `{addresses:{}, riskDetails:[], riskBehaviors:[]}` even when fully clean — it is always truthy. Clean = `simulationError` null AND `risks.riskDetails` empty AND `risks.riskBehaviors` empty. A standby script that checks `if risks:` will wrongly abort a good execute — this bug cost the SIDECOIN free claim on 2026-11-11 (preview clean at T+5s, free pool gone by T+60s). In FCFS scripts, validate the preview fields individually and test the clean-check logic against a real clean preview BEFORE the window opens.

## Chip404 miner fleet (2026-11-02)
- Supervisors launched by a scheduled guard run die with that run's session cleanup (observed twice); a supervisor launched detached from the main chat (`setsid nohup ./supervise.sh`) survives until the next VM replacement. Guard restarts are backup only.
- If two supervisors run at once they split the CPU quota and race on offset.txt (overlapping search ranges). Keep exactly one: kill the worker-launched one by PID, keep the detached one.
- VM replacements kill all processes but `~/workspace` persists, so `offset.txt` keeps the search from re-covering old ranges.
